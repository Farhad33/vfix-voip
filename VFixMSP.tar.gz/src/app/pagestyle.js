'use client'
import styled from 'styled-components'


export const Page = styled.div`
`