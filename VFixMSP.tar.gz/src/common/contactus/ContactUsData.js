
export const Data =  {   
    contact : {
        subject: 'Contact Us Today',
        p: `We are committed to our Partners’ success.Contact us today to start building your cloud business.`,
        buttonName: 'Submit',
        firstName: 'First Name...',
        lastName: 'Last Name...',
        email: 'Email...',
        phone: 'Phone Number...', 
        message: 'Message...',
        sent: 'Your message has been sent.',
        err: 'Your message was not sent',
        image: '/contactUs/contact-us-vfix.svg',
        contactALT: 'Contact VFix MSP image',
    },
}